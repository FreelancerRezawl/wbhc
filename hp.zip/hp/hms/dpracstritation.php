<?php
$localhost = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "hms";

// Create connection
$conn = new mysqli($localhost, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT * FROM fileup"; // Replace 'your_table_name' with the actual table name
$result = $conn->query($sql);

// Check if there are rows in the result set
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row["Id"];
        $title = $row["title"];
        $image = $row["image"];

        // Now you can use these variables to display the data in HTML
    }
} else {
    echo "No records found";
}

// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your HTML Page</title>
</head>
<body>

<?php
// Display the fetched data in your HTML
echo "<h1>ID: $id</h1>";
echo "<h2>Title: $title</h2>";
echo "<img src='$image' alt='Image'>"; // Assuming $image contains the URL or path to the image
?>

</body>
</html>
