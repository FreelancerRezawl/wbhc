<?php
if (isset($_POST['download'])) {
    $file_path = $_POST['file_path'];

    // Set headers for file download
    header("Content-Disposition: attachment; filename=" . basename($file_path));
    header("Content-Type: application/octet-stream");
    header("Content-Length: " . filesize($file_path));
    readfile($file_path);
    exit;
}
?>
