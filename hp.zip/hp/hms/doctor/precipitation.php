<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Image</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <label>Image Upload</label>
        <input type="text" name="title">
        <input type="file" name="file">
        <input type="submit" name="submit">
    </form>
</body>
</html>

<?php
$localhost = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "hms";

$conn = mysqli_connect($localhost, $dbusername, $dbpassword, $dbname);
if(isset($_POST["submit"])) {
    $title = $_POST["title"];
    
    // Ensure the uploaded file is an image
    $allowed_extensions = array("jpg", "jpeg", "png", "gif");
    $file_extension = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));
    
    if (in_array($file_extension, $allowed_extensions)) {
        $pname = rand(1000, 10000) . "-" . $_FILES["file"]["name"];
        $uploads_dir = 'hms/admin/uploadimg';
        
        // Move the uploaded file to the desired directory
        move_uploaded_file($_FILES['file']['tmp_name'], $uploads_dir . $pname);
        
        $sql = "INSERT INTO fileup(title, image) VALUES ('$title', '$pname')";
        
        if(mysqli_query($conn, $sql)) {
            echo "File Successfully Uploaded";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Invalid file format. Only JPG, JPEG, PNG, and GIF files are allowed.";
    }
}
?>
