<?php
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'');
define('DB_NAME', 'hms');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// Fetch specializations from the database
$specialization_query = "SELECT specilization FROM doctors";
$specialization_result = mysqli_query($con, $specialization_query);

$specializations = array();
while ($row = mysqli_fetch_assoc($specialization_result)) {
    $specializations[] = $row['specilization'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Registration Form</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        select {
            height: 34px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
<body>
    <h2>Doctor Registration Form</h2>
    <form action="" method="post">
        <label for="specilization">Specialization:</label>
        <select name="specilization" required>
            <?php foreach ($specializations as $specialization) : ?>
                <option value="<?php echo $specialization; ?>"><?php echo $specialization; ?></option>
            <?php endforeach; ?>
        </select><br>

        <label for="doctorName">Doctor Name:</label>
        <input type="text" name="doctorName" required><br>

        <label for="address">Address:</label>
        <textarea name="address" required></textarea><br>

        <label for="docFees">Doctor Fees:</label>
        <input type="text" name="docFees" required><br>

        <label for="contactno">Contact Number:</label>
        <input type="text" name="contactno" required><br>

        <label for="docEmail">Doctor Email:</label>
        <input type="email" name="docEmail" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <input type="submit" name="submit" value="Register">
    </form>

    <?php
    // Process the registration form
    if (isset($_POST['submit'])) {
        // Retrieve data from the form
        $specilization = mysqli_real_escape_string($con, $_POST['specilization']);
        $doctorName = mysqli_real_escape_string($con, $_POST['doctorName']);
        $address = mysqli_real_escape_string($con, $_POST['address']);
        $docFees = mysqli_real_escape_string($con, $_POST['docFees']);
        $contactno = mysqli_real_escape_string($con, $_POST['contactno']);
        $docEmail = mysqli_real_escape_string($con, $_POST['docEmail']);
        $password = mysqli_real_escape_string($con, $_POST['password']);

        // Insert data into the 'doctors' table
        $query = "INSERT INTO doctors (specilization, doctorName, address, docFees, contactno, docEmail, password, creationDate, updationDate)
                  VALUES ('$specilization', '$doctorName', '$address', '$docFees', '$contactno', '$docEmail', '$password', NOW(), NOW())";

        if (mysqli_query($con, $query)) {
            echo "Registration successful!";
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($con);
        }
    }
    ?>

</body>
</html>
